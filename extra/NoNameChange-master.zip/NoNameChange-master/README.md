# NoNameChange
Blocks in-game name changing. Can be made to ignore admins.
