# Style-C4-Timer
This C4 timer shows the time left until the explosion in a slightly different way. You can choose between multiple different styles, including the default one, i.e. simple countdown to 0. The timer also changes its color when it reaches a certain time - by default it starts with green, on 10 seconds it changes to yellow, and on 5 seconds it becomes red.
