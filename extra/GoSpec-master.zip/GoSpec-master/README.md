# GoSpec
Adds the famous /spec and /back commands, as well as /change.
