# -Ultimate-Fire-in-the-Hole
This plugin allows you to change the messages which show up when you throw a grenade (fire in the hole), to add custom trail with different colors, as well as different sounds for every grenade there is or completely block them.
