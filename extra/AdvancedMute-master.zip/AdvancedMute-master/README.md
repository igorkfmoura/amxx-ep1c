# Advanced-Mute
Adds commands that allow players to mute other players' chat and/or microphone. Includes a mute menu as well.
