# Knife-Models
A simple plugin that adds a menu from which you can choose your Knife skin. The menu can be accessed by typing /knife in the chat.
